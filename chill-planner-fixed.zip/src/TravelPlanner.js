
import React, { useState } from "react";

export default function TravelPlanner() {
  const [formData, setFormData] = useState({
    location: "",
    mood: "",
    days: "",
    people: "",
    budget: ""
  });

  const [itinerary, setItinerary] = useState(null);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const generateItinerary = async () => {
    const prompt = `
      Generate a ${formData.days}-day itinerary for a ${formData.people} trip to ${formData.location}.
      Mood: ${formData.mood}. Budget: INR ${formData.budget}.
      Include flight, hotel and activities with links.
    `;
    
    const response = await fetch("/api/itinerary", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt })
    });

    const data = await response.json();
    setItinerary(data);
  };

  return (
    <div style={{ padding: "2rem" }}>
      <h1>Chill Planner</h1>
      <input placeholder="Destination" onChange={e => handleChange("location", e.target.value)} /><br />
      <input placeholder="Mood" onChange={e => handleChange("mood", e.target.value)} /><br />
      <input placeholder="Days" type="number" onChange={e => handleChange("days", e.target.value)} /><br />
      <input placeholder="People (e.g. couple)" onChange={e => handleChange("people", e.target.value)} /><br />
      <input placeholder="Budget (INR)" type="number" onChange={e => handleChange("budget", e.target.value)} /><br />
      <button onClick={generateItinerary}>Generate Itinerary</button>

      {itinerary && (
        <div style={{ marginTop: "2rem" }}>
          <h2>Your Trip</h2>
          <pre>{JSON.stringify(itinerary, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}
